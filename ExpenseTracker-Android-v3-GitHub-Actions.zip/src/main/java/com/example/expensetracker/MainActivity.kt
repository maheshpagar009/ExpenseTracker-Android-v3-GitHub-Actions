package com.example.expensetracker

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

private val CATEGORIES = listOf("Food","Travel","Fuel","Bills","Shopping","Medical","Education","Other")
private val PAYMENT_MODES = listOf("Cash","UPI","Bank","Card","Other")

data class Expense(val id: Long, val title: String, val amount: Double, val category: String, val date: String, val note: String, val paymentMode: String = "Cash")
data class Income(val id: Long, val title: String, val amount: Double, val date: String, val note: String = "", val paymentMode: String = "Bank")
data class RecurringExpense(val id: Long, val title: String, val amount: Double, val category: String, val day: Int, val paymentMode: String, val active: Boolean = true)

class ExpenseViewModel(private val context: Context): ViewModel() {
    private val prefs = context.getSharedPreferences("expenses", Context.MODE_PRIVATE)
    var expenses by mutableStateOf(loadExpenses()); private set
    var incomes by mutableStateOf(loadIncomes()); private set
    var recurring by mutableStateOf(loadRecurring()); private set
    var monthlyBudget by mutableStateOf(prefs.getFloat("budget", 0f).toDouble()); private set

    init { processRecurring() }

    private fun loadExpenses(): List<Expense> = try {
        val a=JSONArray(prefs.getString("data","[]")); (0 until a.length()).map{val x=a.getJSONObject(it);Expense(x.getLong("id"),x.getString("title"),x.getDouble("amount"),x.getString("category"),x.getString("date"),x.optString("note"),x.optString("paymentMode","Cash"))}.sortedByDescending{it.id}
    } catch(_:Exception){emptyList()}
    private fun loadIncomes(): List<Income> = try {
        val a=JSONArray(prefs.getString("income","[]")); (0 until a.length()).map{val x=a.getJSONObject(it);Income(x.getLong("id"),x.getString("title"),x.getDouble("amount"),x.getString("date"),x.optString("note"),x.optString("paymentMode","Bank"))}.sortedByDescending{it.id}
    } catch(_:Exception){emptyList()}
    private fun loadRecurring(): List<RecurringExpense> = try {
        val a=JSONArray(prefs.getString("recurring","[]")); (0 until a.length()).map{val x=a.getJSONObject(it);RecurringExpense(x.getLong("id"),x.getString("title"),x.getDouble("amount"),x.getString("category"),x.getInt("day"),x.optString("paymentMode","Bank"),x.optBoolean("active",true))}
    } catch(_:Exception){emptyList()}

    private fun saveExpenses(){prefs.edit().putString("data",JSONArray().apply{expenses.forEach{x->put(JSONObject().apply{put("id",x.id);put("title",x.title);put("amount",x.amount);put("category",x.category);put("date",x.date);put("note",x.note);put("paymentMode",x.paymentMode)})}}.toString()).apply()}
    private fun saveIncome(){prefs.edit().putString("income",JSONArray().apply{incomes.forEach{x->put(JSONObject().apply{put("id",x.id);put("title",x.title);put("amount",x.amount);put("date",x.date);put("note",x.note);put("paymentMode",x.paymentMode)})}}.toString()).apply()}
    private fun saveRecurring(){prefs.edit().putString("recurring",JSONArray().apply{recurring.forEach{x->put(JSONObject().apply{put("id",x.id);put("title",x.title);put("amount",x.amount);put("category",x.category);put("day",x.day);put("paymentMode",x.paymentMode);put("active",x.active)})}}.toString()).apply()}

    fun addExpense(title:String,amount:Double,category:String,date:String,note:String,payment:String){expenses=listOf(Expense(System.currentTimeMillis(),title,amount,category,date,note,payment))+expenses;saveExpenses()}
    fun addIncome(title:String,amount:Double,date:String,note:String,payment:String){incomes=listOf(Income(System.currentTimeMillis(),title,amount,date,note,payment))+incomes;saveIncome()}
    fun deleteExpense(id:Long){expenses=expenses.filterNot{it.id==id};saveExpenses()}
    fun deleteIncome(id:Long){incomes=incomes.filterNot{it.id==id};saveIncome()}
    fun setBudget(v:Double){monthlyBudget=v;prefs.edit().putFloat("budget",v.toFloat()).apply()}
    fun addRecurring(title:String,amount:Double,category:String,day:Int,payment:String){recurring=recurring+RecurringExpense(System.currentTimeMillis(),title,amount,category,day,payment);saveRecurring();processRecurring()}
    fun toggleRecurring(id:Long){recurring=recurring.map{if(it.id==id)it.copy(active=!it.active)else it};saveRecurring()}
    fun deleteRecurring(id:Long){recurring=recurring.filterNot{it.id==id};saveRecurring()}
    fun replaceExpenses(items:List<Expense>){expenses=items.distinctBy{it.id}.sortedByDescending{it.id};saveExpenses()}
    fun replaceIncome(items:List<Income>){incomes=items.distinctBy{it.id}.sortedByDescending{it.id};saveIncome()}
    fun replaceRecurring(items:List<RecurringExpense>){recurring=items.distinctBy{it.id};saveRecurring()}
    fun totalExpense()=expenses.sumOf{it.amount}
    fun totalIncome()=incomes.sumOf{it.amount}

    private fun processRecurring(){
        val now=Calendar.getInstance(); val month=now.get(Calendar.MONTH)+1; val year=now.get(Calendar.YEAR); val today=now.get(Calendar.DAY_OF_MONTH)
        var changed=false
        recurring.filter{it.active && today>=it.day}.forEach{r->
            val date="%02d/%02d/%04d".format(r.day,month,year)
            if(expenses.none{it.title==r.title && it.amount==r.amount && it.date==date}){expenses=listOf(Expense(System.currentTimeMillis()+r.id%1000,r.title,r.amount,r.category,date,"Recurring expense",r.paymentMode))+expenses;changed=true}
        }
        if(changed)saveExpenses()
    }
}

class MainActivity: ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{MaterialTheme{val vm:ExpenseViewModel=viewModel(factory=object:androidx.lifecycle.ViewModelProvider.Factory{override fun <T:ViewModel>create(modelClass:Class<T>):T=ExpenseViewModel(applicationContext) as T});App(vm)}}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(vm:ExpenseViewModel){
    var tab by remember{mutableIntStateOf(0)}; var showExpense by remember{mutableStateOf(false)}; var showIncome by remember{mutableStateOf(false)}; var showRecurring by remember{mutableStateOf(false)}; var budgetDialog by remember{mutableStateOf(false)}; var query by remember{mutableStateOf("")}; var budgetText by remember{mutableStateOf("")}
    val context=androidx.compose.ui.platform.LocalContext.current
    val csvLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")){if(it!=null)writeCsv(context,it,vm.expenses,vm.incomes)}
    val pdfLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){if(it!=null)writePdf(context,it,vm.expenses,vm.incomes)}
    val backupLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){if(it!=null)writeBackup(context,it,vm)}
    val restoreLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){if(it!=null)readBackup(context,it,vm)}
    Scaffold(topBar={TopAppBar(title={Text("My Expense Tracker",fontWeight=FontWeight.Bold)},actions={Text("₹ %.0f".format(vm.totalExpense()),modifier=Modifier.padding(end=12.dp))})},bottomBar={NavigationBar{listOf("Dashboard","Transactions","Reports","Settings").forEachIndexed{i,s->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(listOf("⌂","₹","▥","⚙")[i])},label={Text(s)})}}},floatingActionButton={if(tab==0||tab==1)FloatingActionButton(onClick={showExpense=true}){Text("+")}}){pad->Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()){when(tab){0->Dashboard(vm,{showExpense=true},{showIncome=true},{showRecurring=true});1->Transactions(vm,query,{query=it});2->Reports(vm);3->Settings(vm,{budgetDialog=true},{csvLauncher.launch("expenses.csv")},{pdfLauncher.launch("expense-report.pdf")},{backupLauncher.launch("expense-backup.json")},{restoreLauncher.launch(arrayOf("application/json") )},{showRecurring=true})}}}
    if(showExpense)ExpenseDialog(context,vm){showExpense=false}
    if(showIncome)IncomeDialog(context,vm){showIncome=false}
    if(showRecurring)RecurringDialog(context,vm){showRecurring=false}
    if(budgetDialog){AlertDialog(onDismissRequest={budgetDialog=false},title={Text("Monthly Budget")},text={OutlinedTextField(budgetText,{budgetText=it.filter{c->c.isDigit()||c=='.'}},label={Text("Budget (₹)")},singleLine=true)},confirmButton={Button(onClick={vm.setBudget(budgetText.toDoubleOrNull()?:0.0);budgetDialog=false}){Text("Save")}},dismissButton={TextButton(onClick={budgetDialog=false}){Text("Cancel")}})}
}

@Composable fun Dashboard(vm:ExpenseViewModel,addExpense:()->Unit,addIncome:()->Unit,addRecurring:()->Unit){
    val now=Calendar.getInstance();val ms="%02d/%04d".format(now.get(Calendar.MONTH)+1,now.get(Calendar.YEAR));val monthE=vm.expenses.filter{it.date.endsWith(ms)}.sumOf{it.amount};val monthI=vm.incomes.filter{it.date.endsWith(ms)}.sumOf{it.amount};val balance=vm.totalIncome()-vm.totalExpense();val byCat=vm.expenses.filter{it.date.endsWith(ms)}.groupBy{it.category}.mapValues{it.value.sumOf{e->e.amount}}.toList().sortedByDescending{it.second}
    Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("Financial Dashboard",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){MetricCard("Income",monthI,Modifier.weight(1f));MetricCard("Expense",monthE,Modifier.weight(1f))};Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Balance",fontWeight=FontWeight.Bold);Text("₹ %.2f".format(balance),style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);if(vm.monthlyBudget>0)Text("Budget remaining this month: ₹ %.2f".format(vm.monthlyBudget-monthE))}};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick=addExpense,Modifier.weight(1f)){Text("+ Expense")};Button(onClick=addIncome,Modifier.weight(1f)){Text("+ Income")}};Button(onClick=addRecurring,Modifier.fillMaxWidth()){Text("Manage Recurring Expenses")};Text("Where your money goes",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);byCat.take(6).forEach{(cat,v)->val max=(byCat.firstOrNull()?.second?:1.0);Column{Row(Modifier.fillMaxWidth()){Text(cat,Modifier.weight(1f));Text("₹ %.0f".format(v))};LinearProgressIndicator(progress={(v/max).toFloat().coerceIn(0f,1f)},Modifier.fillMaxWidth())}}}
}
@Composable fun MetricCard(label:String,value:Double,modifier:Modifier){Card(modifier){Column(Modifier.padding(14.dp)){Text(label,fontWeight=FontWeight.Bold);Text("₹ %.2f".format(value),style=MaterialTheme.typography.titleLarge)}}}

@Composable fun Transactions(vm:ExpenseViewModel,query:String,setQuery:(String)->Unit){val e=vm.expenses.filter{it.title.contains(query,true)||it.category.contains(query,true)||it.paymentMode.contains(query,true)||it.note.contains(query,true)};val i=vm.incomes.filter{it.title.contains(query,true)||it.paymentMode.contains(query,true)||it.note.contains(query,true)};Column{OutlinedTextField(query,setQuery,label={Text("Search transactions")},modifier=Modifier.fillMaxWidth(),singleLine=true);Spacer(Modifier.height(10.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(e,key={it.id}){x->TransactionCard("EXPENSE",x.title,x.amount,x.category,x.date,x.paymentMode){vm.deleteExpense(x.id)}};items(i,key={it.id}){x->TransactionCard("INCOME",x.title,x.amount,"Income",x.date,x.paymentMode){vm.deleteIncome(x.id)}}}}}
@Composable fun TransactionCard(type:String,title:String,amount:Double,category:String,date:String,payment:String,delete:()->Unit){Card(Modifier.fillMaxWidth()){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.SemiBold);Text("$category • $payment • $date",color=MaterialTheme.colorScheme.onSurfaceVariant)}Column(horizontalAlignment=Alignment.End){Text((if(type=="INCOME")"+ ₹ " else "- ₹ ")+"%.2f".format(amount),fontWeight=FontWeight.Bold);TextButton(onClick=delete){Text("Delete")}}}}}

@Composable fun Reports(vm:ExpenseViewModel){val y=Calendar.getInstance().get(Calendar.YEAR);val months=(1..12).map{m->val key="%02d/%04d".format(m,y);m to vm.expenses.filter{x->x.date.endsWith(key)}.sumOf{it.amount}};val max=months.maxOfOrNull{it.second}?:1.0;Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Reports & Charts",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Expense by month - $y",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);months.forEach{(m,v)->Row(verticalAlignment=Alignment.CenterVertically){Text(SimpleDateFormat("MMM",Locale.getDefault()).format(Calendar.getInstance().apply{set(Calendar.MONTH,m-1)}.time),Modifier.width(45.dp));LinearProgressIndicator(progress={(v/max).toFloat().coerceIn(0f,1f)},Modifier.weight(1f).padding(horizontal=6.dp));Text("₹ %.0f".format(v))}};Text("Payment modes",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);vm.expenses.groupBy{it.paymentMode}.mapValues{it.value.sumOf{e->e.amount}}.forEach{(p,v)->Text("$p  •  ₹ %.2f".format(v))};Text("Total income: ₹ %.2f".format(vm.totalIncome()),fontWeight=FontWeight.Bold);Text("Total expenses: ₹ %.2f".format(vm.totalExpense()),fontWeight=FontWeight.Bold);Text("Net balance: ₹ %.2f".format(vm.totalIncome()-vm.totalExpense()),fontWeight=FontWeight.Bold)}
}

@Composable fun Settings(vm:ExpenseViewModel,setBudget:()->Unit,csv:()->Unit,pdf:()->Unit,backup:()->Unit,restore:()->Unit,recurring:()->Unit){Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Settings",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Budget: "+if(vm.monthlyBudget>0)"₹ %.2f".format(vm.monthlyBudget)else"Not set");Button(onClick=setBudget,Modifier.fillMaxWidth()){Text("Set / Change Monthly Budget")};Button(onClick=csv,Modifier.fillMaxWidth()){Text("Export CSV")};Button(onClick=pdf,Modifier.fillMaxWidth()){Text("Export PDF Report")};Button(onClick=backup,Modifier.fillMaxWidth()){Text("Backup All Data")};Button(onClick=restore,Modifier.fillMaxWidth()){Text("Restore All Data")};Button(onClick=recurring,Modifier.fillMaxWidth()){Text("Recurring Expenses")};Text("Recurring expenses are automatically recorded when you open the app after their scheduled day.",color=MaterialTheme.colorScheme.onSurfaceVariant)}}

@Composable fun ExpenseDialog(context:Context,vm:ExpenseViewModel,close:()->Unit){var title by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var category by remember{mutableStateOf("Other")};var date by remember{mutableStateOf(today())};var note by remember{mutableStateOf("")};var payment by remember{mutableStateOf("UPI")};AlertDialog(onDismissRequest=close,title={Text("Record Expenditure")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)){Field(title,{title=it},"Expense name");Field(amount,{amount=it.filter{c->c.isDigit()||c=='.'}},"Amount (₹)",KeyboardType.Decimal);Field(category,{category=it},"Category (Food, Travel...)");Field(payment,{payment=it},"Payment mode (UPI/Cash/Bank/Card)");Field(date,{date=it},"Date (DD/MM/YYYY)");Field(note,{note=it},"Note")}},confirmButton={Button(onClick={val a=amount.toDoubleOrNull();if(title.isNotBlank()&&a!=null&&validDate(date)){vm.addExpense(title,a,category,date,note,payment);close()}else Toast.makeText(context,"Enter valid name, amount and DD/MM/YYYY date",Toast.LENGTH_SHORT).show()}){Text("Save")}},dismissButton={TextButton(onClick=close){Text("Cancel")}})}
@Composable fun IncomeDialog(context:Context,vm:ExpenseViewModel,close:()->Unit){var title by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var date by remember{mutableStateOf(today())};var note by remember{mutableStateOf("")};var payment by remember{mutableStateOf("Bank")};AlertDialog(onDismissRequest=close,title={Text("Record Income")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){Field(title,{title=it},"Income source");Field(amount,{amount=it.filter{c->c.isDigit()||c=='.'}},"Amount (₹)",KeyboardType.Decimal);Field(payment,{payment=it},"Payment mode");Field(date,{date=it},"Date (DD/MM/YYYY)");Field(note,{note=it},"Note")}},confirmButton={Button(onClick={val a=amount.toDoubleOrNull();if(title.isNotBlank()&&a!=null&&validDate(date)){vm.addIncome(title,a,date,note,payment);close()}else Toast.makeText(context,"Enter valid income and date",Toast.LENGTH_SHORT).show()}){Text("Save")}},dismissButton={TextButton(onClick=close){Text("Cancel")}})}
@Composable fun RecurringDialog(context:Context,vm:ExpenseViewModel,close:()->Unit){var title by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var category by remember{mutableStateOf("Bills")};var day by remember{mutableStateOf("1")};var payment by remember{mutableStateOf("Bank")};Column{};AlertDialog(onDismissRequest=close,title={Text("Recurring Expenses")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)){Text("Add monthly recurring expense",fontWeight=FontWeight.Bold);Field(title,{title=it},"Name (Rent, EMI, etc.)");Field(amount,{amount=it.filter{c->c.isDigit()||c=='.'}},"Amount",KeyboardType.Decimal);Field(category,{category=it},"Category");Field(day,{day=it.filter{c->c.isDigit()}},"Day of month (1-28)");Field(payment,{payment=it},"Payment mode");Divider();vm.recurring.forEach{r->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(r.title,fontWeight=FontWeight.SemiBold);Text("Day ${r.day} • ₹ %.2f • ${r.paymentMode}")};TextButton(onClick={vm.toggleRecurring(r.id)}){Text(if(r.active)"Pause" else"Resume")};TextButton(onClick={vm.deleteRecurring(r.id)}){Text("Delete")}}}},confirmButton={Button(onClick={val a=amount.toDoubleOrNull();val d=day.toIntOrNull();if(title.isNotBlank()&&a!=null&&d!=null&&d in 1..28){vm.addRecurring(title,a,category,d,payment);title="";amount="";Toast.makeText(context,"Recurring expense added",Toast.LENGTH_SHORT).show()}else Toast.makeText(context,"Enter name, amount and day 1-28",Toast.LENGTH_SHORT).show()}){Text("Add")}},dismissButton={TextButton(onClick=close){Text("Close")}})}
@Composable fun Field(value:String,onValue:(String)->Unit,label:String,type:KeyboardType=KeyboardType.Text){OutlinedTextField(value,onValue,label={Text(label)},keyboardOptions=KeyboardOptions(keyboardType=type),singleLine=true,modifier=Modifier.fillMaxWidth())}
fun validDate(s:String)=s.matches(Regex("\\d{2}/\\d{2}/\\d{4}"))
fun today()=SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(Date())
fun esc(s:String)=if(s.contains(",")||s.contains('"'))"\""+s.replace("\"","\"\"")+"\""else s
fun writeCsv(c:Context,u:Uri,expenses:List<Expense>,incomes:List<Income>){c.contentResolver.openOutputStream(u)?.bufferedWriter()?.use{w->w.write("Type,Date,Description,Category,Amount,Payment Mode,Note\n");expenses.sortedBy{it.id}.forEach{x->w.write("Expense,${esc(x.date)},${esc(x.title)},${esc(x.category)},${x.amount},${esc(x.paymentMode)},${esc(x.note)}\n")};incomes.sortedBy{it.id}.forEach{x->w.write("Income,${esc(x.date)},${esc(x.title)},Income,${x.amount},${esc(x.paymentMode)},${esc(x.note)}\n")}};Toast.makeText(c,"CSV exported",Toast.LENGTH_SHORT).show()}
fun writeBackup(c:Context,u:Uri,vm:ExpenseViewModel){val root=JSONObject().put("budget",vm.monthlyBudget);root.put("expenses",JSONArray().apply{vm.expenses.forEach{x->put(JSONObject().put("id",x.id).put("title",x.title).put("amount",x.amount).put("category",x.category).put("date",x.date).put("note",x.note).put("paymentMode",x.paymentMode))}});root.put("income",JSONArray().apply{vm.incomes.forEach{x->put(JSONObject().put("id",x.id).put("title",x.title).put("amount",x.amount).put("date",x.date).put("note",x.note).put("paymentMode",x.paymentMode))}});root.put("recurring",JSONArray().apply{vm.recurring.forEach{x->put(JSONObject().put("id",x.id).put("title",x.title).put("amount",x.amount).put("category",x.category).put("day",x.day).put("paymentMode",x.paymentMode).put("active",x.active))}});c.contentResolver.openOutputStream(u)?.bufferedWriter()?.use{it.write(root.toString(2))};Toast.makeText(c,"Backup created",Toast.LENGTH_SHORT).show()}
fun readBackup(c:Context,u:Uri,vm:ExpenseViewModel){try{val root=JSONObject(c.contentResolver.openInputStream(u)?.bufferedReader()?.use{it.readText()}?:return);val ea=root.getJSONArray("expenses");val il=root.optJSONArray("income")?:JSONArray();val ra=root.optJSONArray("recurring")?:JSONArray();vm.replaceExpenses((0 until ea.length()).map{val x=ea.getJSONObject(it);Expense(x.getLong("id"),x.getString("title"),x.getDouble("amount"),x.getString("category"),x.getString("date"),x.optString("note"),x.optString("paymentMode","Cash"))});vm.replaceIncome((0 until il.length()).map{val x=il.getJSONObject(it);Income(x.getLong("id"),x.getString("title"),x.getDouble("amount"),x.getString("date"),x.optString("note"),x.optString("paymentMode","Bank"))});vm.replaceRecurring((0 until ra.length()).map{val x=ra.getJSONObject(it);RecurringExpense(x.getLong("id"),x.getString("title"),x.getDouble("amount"),x.getString("category"),x.getInt("day"),x.optString("paymentMode","Bank"),x.optBoolean("active",true))});vm.setBudget(root.optDouble("budget",0.0));Toast.makeText(c,"Backup restored",Toast.LENGTH_SHORT).show()}catch(_:Exception){Toast.makeText(c,"Invalid backup file",Toast.LENGTH_SHORT).show()}}
fun writePdf(c:Context,u:Uri,expenses:List<Expense>,incomes:List<Income>){val doc=PdfDocument();val w=842;val h=595;var n=1;var page=doc.startPage(PdfDocument.PageInfo.Builder(w,h,n).create());var canvas=page.canvas;val p=Paint().apply{textSize=16f;isFakeBoldText=true};canvas.drawText("Personal Finance Report",40f,35f,p);p.textSize=10f;p.isFakeBoldText=false;canvas.drawText("Generated: ${today()}   Income: ₹ %.2f   Expenses: ₹ %.2f   Balance: ₹ %.2f".format(incomes.sumOf{it.amount},expenses.sumOf{it.amount},incomes.sumOf{it.amount}-expenses.sumOf{it.amount}),40f,55f,p);var y=82f;fun np(){doc.finishPage(page);n++;page=doc.startPage(PdfDocument.PageInfo.Builder(w,h,n).create());canvas=page.canvas;y=35f};(expenses.map{Triple("Expense",it.date,it.title+" • "+it.category+" • "+it.paymentMode+" • ₹ %.2f".format(it.amount))}+incomes.map{Triple("Income",it.date,it.title+" • "+it.paymentMode+" • ₹ %.2f".format(it.amount))}).sortedByDescending{it.second}.forEach{x->if(y>560)np();canvas.drawText("${x.first}  ${x.second}  ${x.third.take(95)}",40f,y,p);y+=17};doc.finishPage(page);c.contentResolver.openOutputStream(u)?.use{doc.writeTo(it)};doc.close();Toast.makeText(c,"PDF exported",Toast.LENGTH_SHORT).show()}
