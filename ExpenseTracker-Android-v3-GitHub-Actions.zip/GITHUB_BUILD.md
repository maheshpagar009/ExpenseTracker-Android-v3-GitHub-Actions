# Build Expense Tracker APK Without Android Studio

## Requirements
- A GitHub account
- No Android Studio is required on your PC

## Steps
1. Create a new GitHub repository.
2. Upload all files in this project to the repository.
3. Open the repository on GitHub.
4. Select **Actions**.
5. Select **Build Android APK**.
6. Click **Run workflow**.
7. Wait for the build to finish.
8. Open the completed workflow run.
9. Under **Artifacts**, download **ExpenseTracker-debug-apk**.
10. Extract the downloaded artifact and install the `.apk` on your Android phone.

The workflow builds the debug APK in GitHub's cloud using JDK 17 and the Android SDK.
